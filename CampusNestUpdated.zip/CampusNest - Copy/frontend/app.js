// Handle signup form submission
document
  .getElementById("signup-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    // Collect form data
    const userData = {
      firstName: document.getElementById("firstName").value,
      lastName: document.getElementById("lastName").value,
      username: document.getElementById("username").value,
      email: document.getElementById("email").value,
      password: document.getElementById("password").value,
      dob: document.getElementById("dateOfBirth").value,
      phoneNumber: document.getElementById("phoneNumber").value,
      pronouns: document.getElementById("pronouns").value,
      university: document.getElementById("school").value,
      securityQuestion: document.getElementById("securityQuestion").value,
      securityAnswer: document.getElementById("securityAnswer").value,
    };

    // Validation for matching passwords
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;
    if (password !== confirmPassword) {
      alert("Passwords do not match.");
      return;
    }

    // Check for Terms and Conditions acceptance
    const termsAccepted = document.getElementById("agreeTerms").checked;
    if (!termsAccepted) {
      alert("You must agree to the Terms and Conditions.");
      return;
    }

    // Send data to backend for registration
    fetch("/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(userData),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          alert("Account created successfully. You can now log in.");
          window.location.href = "login.html";
        } else {
          alert("Error: " + data.message);
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        alert("An error occurred. Please try again.");
      });
  });

// Handle login form submission
document
  .getElementById("login-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    const loginData = {
      username: document.getElementById("login-username").value,
      password: document.getElementById("login-password").value,
    };

    fetch("/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(loginData),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          alert("Login successful!");

          // Save user info locally for dashboard
          localStorage.setItem("userFirstName", data.firstName);
          localStorage.setItem("userLastName", data.lastName);
          localStorage.setItem("username", data.username);

          // Redirect to dashboard
          window.location.href = `/dashboard`;
        } else {
          alert("Invalid username or password.");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        alert("An error occurred. Please try again.");
      });
  });

// Function to handle showing or hiding the password field (optional)
document.querySelectorAll("input[type='password']").forEach((passwordField) => {
  passwordField.addEventListener("focus", function () {
    this.type = "text"; // Show password on focus for easier typing (optional)
  });

  passwordField.addEventListener("blur", function () {
    this.type = "password"; // Hide password on blur for security (optional)
  });
});

// Fetch and display user information on the dashboard
document.addEventListener("DOMContentLoaded", function () {
  const userFirstName = localStorage.getItem("userFirstName");
  const userLastName = localStorage.getItem("userLastName");

  // Display the name in a designated area, e.g., in a header or sidebar
  if (userFirstName && userLastName) {
    document.getElementById(
      "user-name"
    ).textContent = `Name: ${userFirstName} ${userLastName}`;
  }

  // Automatically log out users if token/session expires
  const logoutLink = document.getElementById("logout-link");
  if (logoutLink) {
    logoutLink.addEventListener("click", () => {
      localStorage.clear(); // Clear local storage data
      alert("You have been logged out.");
      window.location.href = "login.html"; // Redirect to login
    });
  }
});

// Utility function for displaying error messages
function showError(elementId, message) {
  const element = document.getElementById(elementId);
  const errorMessage = document.createElement("div");
  errorMessage.classList.add("error-message");
  errorMessage.textContent = message;
  element.insertAdjacentElement("afterend", errorMessage);

  // Remove error message after a short period
  setTimeout(() => {
    errorMessage.remove();
  }, 5000);
}

// Form validation for password strength (optional enhancement)
document.getElementById("password").addEventListener("input", function () {
  const password = this.value;
  const passwordStrength = checkPasswordStrength(password);

  if (passwordStrength === "weak") {
    showError("password", "Password is too weak.");
  }
});

function checkPasswordStrength(password) {
  if (password.length < 8) return "weak";
  if (!/[A-Z]/.test(password)) return "weak"; // Ensure at least one uppercase
  if (!/[0-9]/.test(password)) return "weak"; // Ensure at least one digit
  if (!/[\W_]/.test(password)) return "weak"; // Ensure at least one special character
  return "strong";
}
