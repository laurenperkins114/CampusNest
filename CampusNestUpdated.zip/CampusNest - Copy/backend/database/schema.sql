-- Create the tasks table
CREATE TABLE tasks (
    task_id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_title TEXT NOT NULL,
    task_description TEXT NOT NULL,
    due_date TEXT NOT NULL, -- Stored as TEXT (YYYY-MM-DD) for compatibility
    created_by INTEGER NOT NULL,
    assigned_to INTEGER,
    status TEXT CHECK(status IN ('pending', 'completed')) DEFAULT 'pending',
    attachments TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users (id),
    FOREIGN KEY (assigned_to) REFERENCES users (id)
);

-- Trigger to update 'updated_at' column
CREATE TRIGGER update_timestamp
AFTER UPDATE ON tasks
FOR EACH ROW
BEGIN
    UPDATE tasks SET updated_at = CURRENT_TIMESTAMP WHERE task_id = OLD.task_id;
END;

-- Create the user_roles table
CREATE TABLE user_roles (
    user_id INTEGER,
    org_id INTEGER,
    role TEXT CHECK(role IN ('leader', 'user')),
    PRIMARY KEY (user_id, org_id),
    FOREIGN KEY (user_id) REFERENCES users (id),
    FOREIGN KEY (org_id) REFERENCES organizations (org_id)
);

-- Indexes for performance optimization
CREATE INDEX idx_tasks_created_by ON tasks (created_by);
CREATE INDEX idx_tasks_assigned_to ON tasks (assigned_to);
