const express = require("express");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const session = require("express-session");
const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Session management
app.use(
  session({
    secret: "secureRandomSecretKey", // Replace with a secure key
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }, // Use secure: true if using HTTPS
  })
);

// Serve static files from the frontend directory
app.use(express.static(path.join(__dirname, "../frontend")));

// Create SQLite database
const db = new sqlite3.Database(":memory:");

// Load SQL schema and initialize the database
db.serialize(() => {
  const schema = `
    CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        dob TEXT NOT NULL,
        phone_number TEXT,
        pronouns TEXT,
        university TEXT,
        security_question TEXT,
        security_answer TEXT
    );
    `;
  db.run(schema, (err) => {
    if (err) {
      console.error("Failed to initialize database schema:", err);
    } else {
      console.log("Database initialized successfully.");
    }
  });
});

// Register endpoint
app.post("/register", (req, res) => {
  const {
    firstName,
    lastName,
    username,
    email,
    password,
    dob,
    phoneNumber,
    pronouns,
    university,
    securityQuestion,
    securityAnswer,
  } = req.body;

  // Hash the password before saving
  bcrypt.hash(password, 10, (err, hashedPassword) => {
    if (err) {
      return res
        .status(500)
        .json({ success: false, message: "Error encrypting password." });
    }

    // Insert the user into the database
    const insertQuery = `
            INSERT INTO users (first_name, last_name, username, email, password, dob, phone_number, pronouns, university, security_question, security_answer)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
    db.run(
      insertQuery,
      [
        firstName,
        lastName,
        username,
        email,
        hashedPassword,
        dob,
        phoneNumber,
        pronouns,
        university,
        securityQuestion,
        securityAnswer,
      ],
      (insertErr) => {
        if (insertErr) {
          console.error("Error inserting user:", insertErr);
          return res.status(500).json({
            success: false,
            message:
              "Failed to register user. Username or email might already exist.",
          });
        }

        res.json({ success: true });
      }
    );
  });
});

// Login endpoint
app.post("/login", (req, res) => {
  const { username, password } = req.body;

  // Check if the user exists
  const selectQuery = `SELECT * FROM users WHERE username = ?`;
  db.get(selectQuery, [username], (err, user) => {
    if (err) {
      console.error("Error finding user:", err);
      return res
        .status(500)
        .json({ success: false, message: "An error occurred." });
    }

    if (!user) {
      return res
        .status(401)
        .json({ success: false, message: "Invalid username or password." });
    }

    // Compare passwords
    bcrypt.compare(password, user.password, (compareErr, isMatch) => {
      if (compareErr || !isMatch) {
        return res
          .status(401)
          .json({ success: false, message: "Invalid username or password." });
      }

      // Store user information in the session
      req.session.user = {
        id: user.id,
        username: user.username,
        firstName: user.first_name,
        lastName: user.last_name,
      };
      // Send user details back to front-end for local storage
      return res.json({
        success: true,
        firstName: user.first_name,
        lastName: user.last_name,
        username: user.username,
      });
      res.json({ success: true, message: "Login successful!" });
    });
  });
});

// Logout endpoint
app.get("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res
        .status(500)
        .json({ success: false, message: "Logout failed." });
    }
    res.clearCookie("connect.sid");
    res.json({ success: true, message: "Logged out successfully." });
  });
});

// Middleware to check if user is authenticated
function isAuthenticated(req, res, next) {
  if (req.session.user) {
    next();
  } else {
    res.status(401).json({ success: false, message: "Unauthorized access." });
  }
}

// Serve HTML pages with session awareness
app.get("/login.html", (req, res) => {
  if (req.session.user) {
    return res.redirect("/dashboard");
  }
  res.sendFile(path.join(__dirname, "../frontend/login.html"));
});

app.get("/signup.html", (req, res) => {
  if (req.session.user) {
    return res.redirect("/dashboard");
  }
  res.sendFile(path.join(__dirname, "../frontend/signup.html"));
});

// Serve the dashboard only if the user is authenticated
app.get("/dashboard", isAuthenticated, (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/index.html"));
});

// Additional route to fetch user data
app.get("/user-data", isAuthenticated, (req, res) => {
  const { id, firstName, lastName, username } = req.session.user;
  res.json({ id, firstName, lastName, username });
});

// Handle 404 errors
app.use((req, res) => {
  res.status(404).send("Page not found.");
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
