// Handle signup form submission
document
  .getElementById("signup-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    // Collect form data
    const userData = {
      firstName: document.getElementById("first-name").value,
      lastName: document.getElementById("last-name").value,
      username: document.getElementById("username").value,
      email: document.getElementById("email").value,
      password: document.getElementById("password").value,
      dob: document.getElementById("dob").value,
      phoneNumber: document.getElementById("phone-number").value,
      pronouns: document.getElementById("pronouns").value,
      university: document.getElementById("university").value,
      securityQuestion: document.getElementById("security-question").value,
      securityAnswer: document.getElementById("security-answer").value,
    };

    // Validation for matching passwords
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm-password").value;
    if (password !== confirmPassword) {
      alert("Passwords do not match.");
      return;
    }

    // Check for Terms and Conditions acceptance
    const termsAccepted = document.getElementById("terms").checked;
    if (!termsAccepted) {
      alert("You must agree to the Terms and Conditions.");
      return;
    }

    // Send data to backend for registration
    fetch("/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(userData),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          alert("Account created successfully. You can now log in.");
          window.location.href = "login.html";
        } else {
          alert("Error: " + data.message);
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        alert("An error occurred. Please try again.");
      });
  });

// Handle login form submission
document
  .getElementById("login-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    const loginData = {
      username: document.getElementById("login-username").value,
      password: document.getElementById("login-password").value,
    };

    fetch("/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(loginData),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          alert("Login successful!");

          // Save user info locally for dashboard
          localStorage.setItem("userFirstName", data.firstName);
          localStorage.setItem("userLastName", data.lastName);
          localStorage.setItem("username", data.username);

          // Redirect to dashboard
          window.location.href = `/dashboard`;
        } else {
          alert("Invalid username or password.");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        alert("An error occurred. Please try again.");
      });
  });

// Function to handle showing or hiding the password field (optional)
document.getElementById("password").addEventListener("focus", function () {
  this.type = "text"; // Show password on focus for easier typing (optional)
});
document.getElementById("password").addEventListener("blur", function () {
  this.type = "password"; // Hide password on blur for security (optional)
});

// Fetch and display user information on the dashboard
document.addEventListener("DOMContentLoaded", function () {
  const userFirstName = localStorage.getItem("userFirstName");
  const userLastName = localStorage.getItem("userLastName");

  // Display the name in a designated area, e.g., in a header or sidebar
  if (userFirstName && userLastName) {
    document.getElementById(
      "user-name"
    ).textContent = `Name: ${userFirstName} ${userLastName}`;
  }
});
